import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SearchSwipeComponent } from './search-swipe/search-swipe.component';
import { ViewProfileComponent } from './view-profile/view-profile.component';

const routes: Routes = [
  { path: '', component: SearchSwipeComponent },
  { path: 'viewprofile', component: ViewProfileComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
