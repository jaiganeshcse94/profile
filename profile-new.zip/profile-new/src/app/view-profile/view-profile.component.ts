import { Component, OnInit } from '@angular/core';
import { PersoneDetailService } from '../persone-detail.service'; 
import { Router } from '@angular/router';
@Component({
  selector: 'app-view-profile',
  templateUrl: './view-profile.component.html',
  styleUrls: ['./view-profile.component.scss']
})
export class ViewProfileComponent implements OnInit {
  cartIconcount:any;
  views=[];
  notviews=[];
  shortlist=[];

  constructor(private person: PersoneDetailService,private router: Router) { 
    this.person.personalSubject.subscribe((data)=>{
      this.cartIconcount=data;
      console.log(data);
    });
    
  }
  profileDeatil=[];
  profiles:any;
  ngOnInit() {
    this.loadProfile();
    this.views=[];
    this.notviews=[];
    this.shortlist=[];
  }

  loadProfile(){
    this.profiles=this.cartIconcount;
    if(localStorage.getItem('profileDetail')){
      this.profileDeatil=JSON.parse(localStorage.getItem('profileDetail'));
      //console.log(this.profileDeatil.slice(-1));
      //console.log(this.cartIconcount);
      this.profiles=this.profileDeatil.slice(-1);
    }
  }
  view(profile){
    alert('Interested');
    this.views.push(profile);
    this.router.navigate(['']);
  }
  notview(profile){
    alert('Not Interested');
    this.notviews.push(profile);
    this.router.navigate(['']);
  }
  shortlisted(profile){
    alert('ShortListed');
    this.shortlist.push(profile);
    this.router.navigate(['']);
  }
  CarouselOptions = { 
    items: 3,
    loop: true,
    nav: true,
    dots: true,
    autoplayHoverPause: true,
    autoplay: false,
    margin: 30,
    navText: [
    "<i class='fa fa-angle-left'></i>",
    "<i class='fa fa-angle-right'></i>"
    ],
    responsive: {
    0: {
    items: 1,
    },
    576: {
    items: 1,
    },
    768: {
    items: 2,
    },
    992: {
    items: 3,
    }
    }}; 
}
