import { Component, OnInit } from '@angular/core';
import { PersoneDetailService } from '../persone-detail.service'; 
import { Router } from '@angular/router';
@Component({
  selector: 'app-search-swipe',
  templateUrl: './search-swipe.component.html',
  styleUrls: ['./search-swipe.component.scss']
})
export class SearchSwipeComponent implements OnInit {
profiles:any;
CarouselOptions:any;
itemCart:any=[];
  constructor(private person: PersoneDetailService,private router: Router) {
    this.person.getJSON().subscribe((data) => {
      console.warn(data.profile);
      this.profiles=data.profile;
    });
   }
  ngOnInit() {
    this.CarouselOptions = { 
      items: 3,
      loop: true,
      nav: true,
      dots: true,
      autoplayHoverPause: true,
      autoplay: false,
      margin: 30,
      navText: [
      "<i class='fa fa-angle-left'></i>",
      "<i class='fa fa-angle-right'></i>"
      ],
      responsive: {
      0: {
      items: 1,
      },
      576: {
      items: 1,
      },
      768: {
      items: 2,
      },
      992: {
      items: 3,
      }
      }}; 
  } 
  view(profile:any){
    let profileData=localStorage.getItem('profileDetail');
    if(profileData==null){
      let strorageDataget=[];
      strorageDataget.push(profile);
      localStorage.setItem('profileDetail',JSON.stringify(strorageDataget));
      this.router.navigate(['/viewprofile']);
    }
    else{
      var name=profile.name;
      let index:number=-1;
      this.itemCart=JSON.parse(localStorage.getItem('profileDetail'));
      // for(var i=0;i<this.itemCart.length;i++){
      //   if(String(name) === String(this.itemCart[i].name)){
      //     this.itemCart[i].count = profile.count;
      //     index = i;
      //     break;
      //   }
      // }
      
      if(index == -1){
        this.itemCart.push(profile);
        localStorage.setItem('profileDetail',JSON.stringify(this.itemCart));
      }
      else{
        localStorage.setItem('profileDetail',JSON.stringify(this.itemCart));
      }
      this.router.navigate(['/viewprofile']);
    }
  }

  
}
