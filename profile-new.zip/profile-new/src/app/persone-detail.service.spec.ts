import { TestBed } from '@angular/core/testing';

import { PersoneDetailService } from './persone-detail.service';

describe('PersoneDetailService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PersoneDetailService = TestBed.get(PersoneDetailService);
    expect(service).toBeTruthy();
  });
});
